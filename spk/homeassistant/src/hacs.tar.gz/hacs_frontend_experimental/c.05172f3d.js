const t=(t,e,n)=>t(`component.${e}.title`)||(null==n?void 0:n.name)||e,e=(t,e)=>t.callWS({type:"manifest/get",integration:e});export{t as d,e as f};
